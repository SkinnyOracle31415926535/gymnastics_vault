# ✧ 𓊆 NGA Super Skills 𓊇 ✧

---

## -- Overview --

*(Add general notes about NGA Super Skills requirements here)*

---

## 𓊈 Floor Exercise 𓊉

### Super Skills
| Skill | Description | Points |
|-------|-------------|--------|
| | | |

---

## 𓊈 Pommel Horse / Mushroom 𓊉

### Super Skills
| Skill | Description | Points |
|-------|-------------|--------|
| | | |

---

## 𓊈 Still Rings 𓊉

### Super Skills
| Skill | Description | Points |
|-------|-------------|--------|
| | | |

---

## 𓊈 Vault 𓊉

### Super Skills
| Skill | Description | Points |
|-------|-------------|--------|
| | | |

---

## 𓊈 Parallel Bars 𓊉

### Super Skills
| Skill | Description | Points |
|-------|-------------|--------|
| | | |

---

## 𓊈 High Bar 𓊉

### Super Skills
| Skill | Description | Points |
|-------|-------------|--------|
| | | |

---

## -- Resources & Links --

| Resource | Link |
|----------|------|
| | |

---
