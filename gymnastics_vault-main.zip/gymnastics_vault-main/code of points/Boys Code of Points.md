# ✧ 𓊆 Boys Code of Points 𓊇 ✧

---

## -- Overview --

*(Add general notes about the USAG/FIG Code of Points here)*

---

## 𓊈 Floor Exercise 𓊉

### Element Groups
| Group | Description | Value |
|-------|-------------|-------|
| | | |

### Deductions
| Deduction | Amount |
|-----------|--------|
| | |

---

## 𓊈 Pommel Horse 𓊉

### Element Groups
| Group | Description | Value |
|-------|-------------|-------|
| | | |

### Deductions
| Deduction | Amount |
|-----------|--------|
| | |

---

## 𓊈 Still Rings 𓊉

### Element Groups
| Group | Description | Value |
|-------|-------------|-------|
| | | |

### Deductions
| Deduction | Amount |
|-----------|--------|
| | |

---

## 𓊈 Vault 𓊉

### Element Groups
| Group | Description | Value |
|-------|-------------|-------|
| | | |

### Deductions
| Deduction | Amount |
|-----------|--------|
| | |

---

## 𓊈 Parallel Bars 𓊉

### Element Groups
| Group | Description | Value |
|-------|-------------|-------|
| | | |

### Deductions
| Deduction | Amount |
|-----------|--------|
| | |

---

## 𓊈 High Bar 𓊉

### Element Groups
| Group | Description | Value |
|-------|-------------|-------|
| | | |

### Deductions
| Deduction | Amount |
|-----------|--------|
| | |

---

## -- Resources & Links --

| Resource | Link |
|----------|------|
| | |

---
