# California Sports Center — All-Around Rankings (Unified Meet)

|   Rank |   Num | Name            | Gym   |   Floor |   Pommel |   Rings |   Vault |   PBars |   HiBar |   AA |
|-------:|------:|:----------------|:------|--------:|---------:|--------:|--------:|--------:|--------:|-----:|
|      1 |  3150 | Jace Jackson    | CSC   |     9.2 |      8.5 |     8.8 |     8.8 |     8.7 |     9.6 | 53.6 |
|      2 |  3130 | Kaleb Muolic    | CSC   |     9   |      9   |     8.7 |     9.1 |     8.2 |     8.9 | 52.9 |
|      3 |  3152 | Lev Osipov      | CSC   |     8.7 |      9.1 |     8.6 |     8.5 |     8.5 |     9   | 52.4 |
|      4 |  3129 | Owen Lavrich    | CSC   |     7.9 |      8   |     8.8 |     8.8 |     8.2 |     9   | 50.7 |
|      5 |  3153 | Vlad Samoilenka | CSC   |     8.4 |      8   |     8   |     8.7 |     8.3 |     8.4 | 49.8 |
|      6 |  3131 | Remy Vaughan    | CSC   |     7.4 |      8.6 |     8.4 |     8.9 |     7.7 |     8.5 | 49.5 |
|      7 |  3132 | Aaron Wei       | CSC   |     8.2 |      7.7 |     8.4 |     8.1 |     7.8 |     8.6 | 48.8 |
|      8 |  3128 | Sylvan Fedkiw   | CSC   |     8   |      7.8 |     7.9 |     8.7 |     8   |     8   | 48.4 |
