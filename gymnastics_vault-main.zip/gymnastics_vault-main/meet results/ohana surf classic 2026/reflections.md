# Reflections — 2026 Ohana’s Surf Classic (CSC)

This document captures a **numeric, event-by-event analysis** of how **California Sports Center (CSC)** compared to the rest of the field.
Scoring basis throughout:

> **Team score = sum of the top 3 scores per event (whole meet, no age groups)**

CSC **finished 5th overall**.

---

## Team Totals (Context)

- **CSC team total:** **159.8**
- **Estimated 4th place:** ~**161.0–161.5**
- **Gap to 4th:** ~**1.2–1.7**
- **Estimated podium (3rd):** ~**163.0**
- **Gap to podium:** ~**3.0–3.5**

The gap is driven primarily by **two events**, not systemic weakness.

---

## Floor

| Team | Floor Total |
|---|---|
| Clovis Academy | **27.7** |
| Accel | 26.9 |
| **CSC** | **26.9** |
| IFG | 26.7 |
| HOH-CA | 26.7 |

- CSC vs leader: **−0.8**
- CSC vs most teams: **+0.2 to +0.5**

**Assessment:**  
Floor is a **strength**. It keeps CSC competitive and does not contribute to the 5th-place finish.

---

## Pommel

| Team | Pommel Total |
|---|---|
| Clovis Academy | **26.9** |
| **CSC** | **26.7** |
| Accel | 26.0 |
| IFG | 25.9 |
| HOH-CA | 25.8 |

- CSC vs leader: **−0.2**
- CSC vs rest of field: **+0.7 to +0.9**

**Assessment:**  
Pommel is a **clear competitive advantage** and one of CSC’s best relative events.

---

## Rings

| Team | Rings Total |
|---|---|
| Clovis Academy | **27.3** |
| Accel | 27.0 |
| HOH-CA | 26.8 |
| **CSC** | **26.3** |
| IFG | 26.3 |

- CSC vs leader: **−1.0**
- CSC vs podium cutoff: **−0.5**

**Assessment:**  
Rings is **neutral-to-negative**. Solid execution, but meaningful tenths are left compared to top teams.

---

## Vault

| Team | Vault Total |
|---|---|
| Clovis Academy | **27.8** |
| IFG | 27.6 |
| Accel | 27.5 |
| HOH-CA | 27.5 |
| **CSC** | **26.8** |

- CSC vs leader: **−1.0**
- CSC vs mid-pack (3rd–4th): **−0.7**

**Assessment:**  
Vault is a **ranking limiter**. This single event costs CSC **~0.7–1.0 points**.

---

## Parallel Bars (Largest Deficit)

| Team | PBars Total |
|---|---|
| IFG | **26.6** |
| Clovis Academy | 26.1 |
| Accel | 26.1 |
| HOH-CA | 26.0 |
| Mastery of Sports | 25.6 |
| **CSC** | **25.5** |

- CSC vs leader: **−1.1**
- CSC vs mid-pack: **−0.5**

**Assessment:**  
Parallel bars is the **single biggest contributor** to CSC’s 5th-place finish.

---

## High Bar

| Team | High Bar Total |
|---|---|
| Clovis Academy | **28.8** |
| Accel | 28.3 |
| **CSC** | **27.6** |
| IFG | 27.3 |
| HOH-CA | 27.1 |

- CSC vs leader: **−1.2**
- CSC vs most teams: **+0.3 to +0.5**

**Assessment:**  
High bar is a **top-tier strength** and helps offset weaker events.

---

## Net Event Impact Summary

### Net Positives
- Floor: **+0.2 to +0.5**
- Pommel: **+0.7 to +0.9**
- High Bar: **+0.3 to +0.5**

### Net Negatives
- Rings: **−0.5**
- Vault: **−0.7 to −1.0**
- Parallel Bars: **−0.5 to −1.1**

> **Vault + Parallel Bars together account for ~1.2–2.0 points lost**, which aligns closely with:
> - the gap to **4th**
> - and much of the gap to the **podium**

---

## Final Takeaways

- CSC finished **5th**, not due to broad weakness.
- The meet outcome is explained numerically by **Vault and Parallel Bars**.
- Improving **either** event modestly likely moves CSC to **4th**.
- Improving **both** events makes **podium contention realistic**.

This analysis identifies **where tenths matter most**, enabling targeted training priorities rather than diffuse changes.
