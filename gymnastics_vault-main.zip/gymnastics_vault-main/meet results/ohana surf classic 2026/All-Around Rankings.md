# 2026 Ohana’s Surf Classic — All-Around Rankings

|   Rank |   Num | Name                   | Gym                  |   Floor |   Pommel |   Rings |   Vault |   PBars |   HiBar |   AA |
|-------:|------:|:-----------------------|:---------------------|--------:|---------:|--------:|--------:|--------:|--------:|-----:|
|      1 |  3125 | Jace Carrubba-Katz     | IFG                  |     9.4 |      8.9 |     8.9 |     9.6 |     8.6 |     9.2 | 54.6 |
|      2 |  3108 | Ukiah Warkentin        | Clovis Academy       |     9.3 |      9.3 |     8.7 |     9.2 |     8.9 |     9   | 54.4 |
|      3 |  3119 | Amahn Bolton           | HOH-CA               |     9   |      8.9 |     9   |     9.1 |     8.8 |     9.5 | 54.3 |
|      4 |  3143 | Lucas Trias            | Clovis Academy       |     9.1 |      8.4 |     8.7 |     9.4 |     8.8 |     9.9 | 54.3 |
|      5 |  3107 | Calvin Stabbe          | Clovis Academy       |     8.7 |      9   |     9.2 |     9.4 |     8.9 |     8.8 | 54   |
|      6 |  3139 | Keller Krashinsky      | Accel                |     9.1 |      8.7 |     8.9 |     8.9 |     8.9 |     9.4 | 53.9 |
|      7 |  3141 | Anderson Reed          | Accel                |     9   |      8.7 |     9.3 |     9.1 |     8.2 |     9.5 | 53.8 |
|      8 |  3126 | Finn Lin               | IFG                  |     9.1 |      8.6 |     9.1 |     8.8 |     9.2 |     8.9 | 53.7 |
|      9 |  3150 | Jace Jackson           | CSC                  |     9.2 |      8.5 |     8.8 |     8.8 |     8.7 |     9.6 | 53.6 |
|     10 |  3140 | Ido Lotsvin            | Accel                |     8.8 |      8.6 |     8.6 |     9.2 |     8.6 |     9.4 | 53.2 |
|     11 |  3138 | Rory Heckerman         | Accel                |     8.8 |      8.6 |     9.1 |     9.2 |     8.6 |     8.9 | 53.2 |
|     12 |  3118 | Masis Minassian        | Clovis Academy       |     9   |      8.7 |     8.8 |     9.2 |     8.4 |     9.1 | 53.2 |
|     13 |  3120 | Jules Collins          | HOH-CA               |     8.8 |      8.7 |     9   |     9.4 |     8.6 |     8.6 | 53.1 |
|     14 |  3105 | Jett Adams             | Clovis Academy       |     8.6 |      8   |     9.3 |     9.1 |     8.8 |     9.2 | 53   |
|     15 |  3130 | Kaleb Muolic           | CSC                  |     9   |      9   |     8.7 |     9.1 |     8.2 |     8.9 | 52.9 |
|     16 |  3152 | Lev Osipov             | CSC                  |     8.7 |      9.1 |     8.6 |     8.5 |     8.5 |     9   | 52.4 |
|     17 |  3148 | Kingston Gadsden       | IFG                  |     8.2 |      8.4 |     8.7 |     9.2 |     8.6 |     9.2 | 52.3 |
|     18 |  3145 | Sasha Hacker           | HOH-CA               |     8   |      8.6 |     9.2 |     8.7 |     8.6 |     9   | 52.1 |
|     19 |  3102 | Sebastian Marte-Corona | Mastery of Sports    |     9.3 |      8.7 |     7.2 |     8.8 |     8.6 |     8.9 | 51.5 |
|     20 |  3111 | Zion Canales           | Gymnastics Unlimited |     8   |      8.6 |     8.6 |     8.7 |     8.7 |     8.8 | 51.4 |
|     21 |  3123 | Kyle Renaldi           | HOH-CA               |     8.9 |      8.5 |     8.7 |     8.8 |     7.8 |     8.6 | 51.3 |
|     22 |  3113 | Jeronimo Estrella      | Gymnastics Unlimited |     8.6 |      8.7 |     7.9 |     9.5 |     8   |     8.3 | 51   |
|     23 |  3137 | Oliver Sanhamel        | Mastery of Sports    |     8.4 |      7.6 |     9   |     8.7 |     8.1 |     8.9 | 50.7 |
|     24 |  3106 | Rhys Bennetts          | Clovis Academy       |     7.9 |      8.6 |     8.7 |     8.6 |     8.5 |     8.4 | 50.7 |
|     25 |  3129 | Owen Lavrich           | CSC                  |     7.9 |      8   |     8.8 |     8.8 |     8.2 |     9   | 50.7 |
|     26 |  3136 | Clark Pickett          | Mastery of Sports    |     8.7 |      8.3 |     8.2 |     8.5 |     8.3 |     8.5 | 50.5 |
|     27 |  3147 | Julián Del Toro        | IFG                  |     7.9 |      8.1 |     8.4 |     8.7 |     8.8 |     8.5 | 50.4 |
|     28 |  3121 | Tokuichiro Kamada      | HOH-CA               |     7.9 |      8.1 |     9   |     8.6 |     7.8 |     8.9 | 50.3 |
|     29 |  3114 | Coda Asmuth            | Monterey Bay         |     8   |      7.8 |     8.7 |     8.5 |     8.6 |     8.6 | 50.2 |
|     30 |  3153 | Vlad Samoilenka        | CSC                  |     8.4 |      8   |     8   |     8.7 |     8.3 |     8.4 | 49.8 |
|     31 |  3122 | Teddy Ling             | HOH-CA               |     7.9 |      7.9 |     8.6 |     9.5 |     7.8 |     7.8 | 49.5 |
|     32 |  3131 | Remy Vaughan           | CSC                  |     7.4 |      8.6 |     8.4 |     8.9 |     7.7 |     8.5 | 49.5 |
|     33 |  3134 | Aaron Archer           | Mastery of Sports    |     8.3 |      7.7 |     8.8 |     8.5 |     8.2 |     8   | 49.5 |
|     34 |  3103 | Milo Solis             | Mastery of Sports    |     8.4 |      7.6 |     8.5 |     8.4 |     8.3 |     8.2 | 49.4 |
|     35 |  3101 | Aiden Lamb             | Mastery of Sports    |     8.5 |      8.1 |     7.9 |     8.3 |     8.3 |     8.1 | 49.2 |
|     36 |  3109 | Miles Kim              | IFG                  |     8.2 |      7.4 |     8.2 |     8.4 |     8.4 |     8.3 | 48.9 |
|     37 |  3132 | Aaron Wei              | CSC                  |     8.2 |      7.7 |     8.4 |     8.1 |     7.8 |     8.6 | 48.8 |
|     38 |  3142 | Grayson Galvez         | Clovis Academy       |     8.3 |      7.8 |     8   |     9   |     7.8 |     7.8 | 48.7 |
|     39 |  3135 | Rudy Contreras         | Mastery of Sports    |     8.7 |      7.9 |     8.3 |     8.2 |     8.2 |     7.4 | 48.7 |
|     40 |  3128 | Sylvan Fedkiw          | CSC                  |     8   |      7.8 |     7.9 |     8.7 |     8   |     8   | 48.4 |
|     41 |  3112 | Wilder Christensen     | Gymnastics Unlimited |     6.9 |      7.9 |     8.1 |     8.4 |     7.9 |     8.5 | 47.7 |
|     42 |  3144 | Aiden Bennani          | HOH-CA               |     7.3 |      7.6 |     7.8 |     8.7 |     7.6 |     7.3 | 46.3 |
|     43 |  3115 | Santhiago Rosales      | Monterey Bay         |     8.1 |      7.4 |     7.8 |     8.6 |     7.2 |     7   | 46.1 |
|     44 |  3100 | Michael Hewitt         | Mastery of Sports    |     8.1 |      7.6 |     7.5 |     8.1 |     6.8 |     6.8 | 44.9 |
|     45 |  3104 | Wyatt Wickstrom        | Mastery of Sports    |     7.6 |      7.7 |     7.3 |     8.9 |     7   |     6   | 44.5 |