# West Coast Classic 2026 — Cal Sports Center Event Highlights
**Date:** January 11, 2026  
**Session:** 5  
**Level:** 3

---

## Floor
- **Lev Osipov:** 8.800 (tied 3rd overall)
- **Jace Jackson:** 8.800 (tied 3rd overall)
- **Kaleb Muolic:** 8.100 (1st in 7 yrs division)

---

## Pommel Horse
- **Lev Osipov:** 9.300 (tied 2nd overall) ⭐
- **Kaleb Muolic:** 9.100 (1st in 7 yrs division) ⭐
- **Jace Jackson:** 8.800 (tied 3rd)

---

## Rings
- **Lev Osipov:** 9.200 (tied 2nd overall) ⭐
- **Kaleb Muolic:** 8.500 (1st in 7 yrs division)
- **Jace Jackson:** 8.300 (10th) — needs work

---

## Vault
- **Lev Osipov:** 9.600 (tied 2nd overall) ⭐
- **Aaron Wei:** 9.400 (2nd in 8 yrs division) ⭐
- **Sylvan Fedkiw:** 9.200 (tied 3rd in 8 yrs)
- **Jace Jackson:** 9.100
- **Owen Lavrich:** 9.100
- **Kaleb Muolic:** 9.000

---

## Parallel Bars
- **Kaleb Muolic:** 8.600 (1st in 7 yrs division) ⭐
- **Lev Osipov:** 8.600
- **Owen Lavrich:** 8.600
- **Jace Jackson:** 8.500

---

## High Bar
- **Jace Jackson:** 9.000 (TIED 1ST OVERALL) 🥇⭐
- **Lev Osipov:** 8.700 (5th overall)
- **Kaleb Muolic:** 7.500 — biggest area for improvement
