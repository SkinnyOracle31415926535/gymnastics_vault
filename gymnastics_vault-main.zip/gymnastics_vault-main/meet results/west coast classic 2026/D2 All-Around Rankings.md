# West Coast Classic 2026 — Level 3 Division 2 All-Around Rankings
**Date:** January 11, 2026  
**Session:** 5  
**Level:** 3D2

---

## All-Around Podium (D2)
🥇 **Oliver Wong** (CAL Strong - NC) - 51.000  
🥈 **Valentino Negrete Guillen** (CAL Strong - NC) - 49.100  
🥉 **Joshua Teng** (CAL Strong - NC) - 49.000

---

## Full Division 2 Results

| Place | Gymnast | Team | DIV | Floor | Pommel | Rings | Vault | P-Bars | High Bar | AA |
|-------|---------|------|-----|-------|--------|-------|-------|--------|----------|------|
| 1 | Oliver Wong | CAL Strong - NC | D2 | 8.600 ¹ | 8.500 ¹ | 8.500 ¹ | 9.800 ¹ | 8.300 ² | 7.300 ⁴ | **51.000** |
| 2 | Valentino Negrete Guillen | CAL Strong - NC | D2 | 8.100 ³ | 7.800 ⁴ | 8.000 ²ᵀ | 9.300 ³ | 8.200 ³ | 7.700 ²ᵀ | **49.100** |
| 3 | Joshua Teng | CAL Strong - NC | D2 | 8.500 ² | 8.300 ² | 7.900 ⁴ | 8.200 ⁶ | 8.400 ¹ | 7.700 ²ᵀ | **49.000** |
| 4 | Levi Christianson | CAL Strong - NC | D2 | 6.600 ⁵ | 8.000 ³ | 8.000 ²ᵀ | 9.400 ² | 7.200 ⁶ | 7.900 ¹ | **47.100** |
| 5 | Ethan Kong | CAL Strong - NC | D2 | 6.800 ⁴ | 7.500 ⁵ | 7.000 ⁶ | 9.100 ⁴ | 7.600 ⁴ᵀ | 7.000 ⁵ | **45.000** |
| 6 | John Litvinchuk | CAL Strong - NC | D2 | 6.000 ⁶ | 7.300 ⁶ | 7.300 ⁵ | 9.000 ⁵ | 7.600 ⁴ᵀ | 6.800 ⁶ | **44.000** |
| — | Maksim ILchenko | CAL Strong - NC | D2 | — | — | — | — | — | — | **0** |
