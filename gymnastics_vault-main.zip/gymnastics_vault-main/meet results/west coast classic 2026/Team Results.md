# West Coast Classic 2026 — Team Results
**Date:** January 11, 2026  
**Session:** 5  
**Level:** 3

---

## Team Standings (Top 3 AA Scores)

| Place | Team | Top 3 Gymnasts | Team Score |
|-------|------|----------------|------------|
| 🥇 1 | **Accel - NC** | Krashinsky (53.9), Reed (53.5), Lotsvin (53.2) | **160.600** |
| 🥈 2 | **Clovis Academy** | Warkentin (54.7), Adams (52.8), Stabbe (52.5) | **160.000** |
| 🥉 3 | **IGC - NC** | Malhi (53.4), Rojas (52.7), Lin (52.2) | **158.300** |
| 4 | **Cal Sports Ctr** | Osipov (54.2), Jackson (52.5), Muolic (50.8) | **157.500** |
| 5 | **HOH - NC** | Bolton (53.9), Hacker (52.1), Collins (50.0) | **156.000** |
| 6 | **EGA - NC** | Hak (49.2), Fujii (48.1), del Pozo (47.8) | **145.100** |
| 7 | **CCG - SLO - NC** | Railsback (49.2), Zarate (48.4), Kowalczyk (46.7) | **144.300** |
| 8 | **CAL Strong - NC** (D2) | Wong (51.0), Negrete Guillen (49.1), Teng (49.0) | **149.100** |
