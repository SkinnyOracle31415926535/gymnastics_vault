# West Coast Classic 2026 — California Sports Center Scores
**Date:** January 11, 2026  
**Session:** 5  
**Level:** 3

---

## Cal Sports Center Results

| Place | Gymnast         | DIV   | Floor | Pommel | Rings | Vault | P-Bars | High Bar | AA         |
| ----- | --------------- | ----- | ----- | ------ | ----- | ----- | ------ | -------- | ---------- |
| 2     | Lev Osipov      | 9 yrs | 8.800 | 9.300  | 9.200 | 9.600 | 8.600  | 8.700    | **54.200** |
| 11    | Jace Jackson    | 9 yrs | 8.800 | 8.800  | 8.300 | 9.100 | 8.500  | 9.000    | **52.500** |
| 16    | Kaleb Muolic    | 7 yrs | 8.100 | 9.100  | 8.500 | 9.000 | 8.600  | 7.500    | **50.800** |
| 24    | Owen Lavrich    | 8 yrs | 7.000 | 8.300  | 8.000 | 9.100 | 8.600  | 8.100    | **49.100** |
| 25    | Aaron Wei       | 8 yrs | 7.200 | 8.200  | 7.500 | 9.400 | 7.900  | 8.200    | **48.400** |
| 32    | Sylvan Fedkiw   | 8 yrs | 7.200 | 7.600  | 8.200 | 9.200 | 8.300  | 7.000    | **47.500** |
| 33    | Remy Vaughan    | 8 yrs | 7.400 | 7.800  | 7.800 | 8.900 | 7.500  | 7.900    | **47.300** |
| 35    | Vlad Samoilenka | 9 yrs | 7.400 | 8.200  | 7.000 | 8.500 | 8.300  | 7.800    | **47.200** |
| 37    | Aarush Kini     | 9 yrs | 7.300 | 8.400  | 7.200 | 8.800 | 7.300  | 7.900    | **46.900** |

**Team Top 3 Total:** 157.500
