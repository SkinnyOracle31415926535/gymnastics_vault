# Stanford Open 2026 — Team Results
**Stanford Men's Gymnastics · Level 3D1 · Session 9**  
Jan 23–25, 2026 · Stanford, CA

## Team Results (Top 3 AA Scores Count)
| Rank | Team | Team Score | Counting AAs |
|------|------|------------|--------------|
| 1 | International Gymnastics Centre | 166.200 | 56.200, 55.200, 54.800 |
| 2 | Bayshore Elite Gymnastics | 164.600 | 56.400, 54.500, 53.700 |
| 3 | Clovis Academy of Gymnastics and Dance | 163.800 | 55.600, 54.400, 53.800 |
| 4 | Emerald City Gymnastics Academy | 163.300 | 54.900, 54.400, 54.000 |
| 5 | California Sports Center | 158.900 | 53.500, 53.000, 52.400 |
| 6 | Mastery of Sports | 158.600 | 53.800, 52.800, 52.000 |
