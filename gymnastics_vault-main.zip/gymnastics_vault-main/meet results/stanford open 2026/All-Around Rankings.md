# Stanford Open 2026 — Individual All-Around Results
**Stanford Men's Gymnastics · Level 3D1 · Session 9**  
Jan 23–25, 2026 · Stanford, CA

## Full Meet — Individual All-Around Results (All Athletes)
| Rank | Gymnast | Gym | AA |
|------|---------|-----|----|
| 1 | Theo Mazza | Bayshore Elite | 56.400 |
| 2 | Jesaiah Rojas | International GC | 56.200 |
| 3 | Ukiah Warkentin | Clovis | 55.600 |
| 4 | Yuvi Malhi | International GC | 55.200 |
| 5 | Oliver Yang | Emerald City | 54.900 |
| 6 | Arthur Lin | International GC | 54.800 |
| 7 | Cleo Dong | Bayshore Elite | 54.500 |
| 8 | Peng-Yu Pan | Emerald City | 54.400 |
| 8 | Jett Adams | Clovis | 54.400 |
| 10 | Hiro King | Emerald City | 54.000 |
| 10 | Chase LaCentra | Gold Country | 54.000 |
| 12 | Calvin Stabbe | Clovis | 53.800 |
| 12 | Sebastian Marte-Corona | Mastery of Sports | 53.800 |
| 14 | Aitor Kirschberg | Bayshore Elite | 53.700 |
| 15 | Kaleb Muolic | California Sports Center | 53.500 |
| 16 | Josiah Yu | SBG Athletics | 53.400 |
| 17 | Max Blair | Emerald City | 53.300 |
| 18 | Lev Osipov | California Sports Center | 53.000 |
| 18 | Masis Minassian | Clovis | 53.000 |
| 18 | Jaiden Flores | Bayshore Elite | 53.000 |
| 21 | Evert Vidales | Emerald City | 52.900 |
| 22 | Clark Pickett | Mastery of Sports | 52.800 |
| 22 | Lucas Trias |  | 52.800 |
| 24 | Kyson Liang | Technique | 52.700 |
| 24 | Sebastian Zawadzki | Bayshore Elite | 52.700 |
| 26 | Jace Jackson | California Sports Center | 52.400 |
| 27 | Akito del Pozo | Elevate | 52.300 |
| 28 | Jack Rawstron | Emerald City | 52.100 |
| 29 | Oliver Sanhamel | Mastery of Sports | 52.000 |
| 30 | James Dickson | International GC | 51.900 |
| 31 | Evan Fugate | International GC | 51.700 |
| 31 | Luc Ortiz | Bayshore Elite | 51.700 |
| 33 | Aiden Lamb | Mastery of Sports | 51.600 |
| 33 | Maxim Marks | Bayshore Elite | 51.600 |
| 35 | Rhys Bennetts | Clovis | 51.100 |
| 35 | Winston Zachary | Metropolitan | 51.100 |
| 35 | Milo Solis | Mastery of Sports | 51.100 |
| 38 | Femi Omiwade | Interstellar | 51.000 |
| 39 | Remy Vaughan | California Sports Center | 50.900 |
| 40 | Caleb Rivera | Emerald City | 50.700 |
| 41 | Jovian Tang | Emerald City | 50.600 |
| 41 | Zack Drazba | Bayshore Elite | 50.600 |
| 43 | Koichi Takayama | SBG Athletics | 50.500 |
| 44 | John Theodorou | Emerald City | 50.400 |
| 45 | Ashar Hafeez |  | 50.300 |
| 46 | Theo Derrick | Emerald City | 49.800 |
| 47 | Aaron Archer | Mastery of Sports | 49.700 |
| 48 | Cody Kirsch | Emerald City | 49.500 |
| 48 | Saarik Goldman | Metropolitan | 49.500 |
| 50 | Owen Lavrich | California Sports Center | 49.300 |
| 51 | Rudy Contreras | Mastery of Sports | 49.000 |
| 52 | Sylvan Fedkiw | California Sports Center | 48.800 |
| 52 | Aaron Wei | California Sports Center | 48.800 |
| 54 | Grayson Galvez | Clovis | 48.700 |
| 55 | Aarush Kini | California Sports Center | 48.600 |
| 56 | Seth Derrick | Emerald City | 48.000 |
| 57 | Ekrem Utemissov | SBG Athletics | 47.900 |
| 58 | Jarren Wang | Elevate | 47.500 |
| 59 | Kenton Fujii | Elevate | 47.400 |
| 60 | Michael Hewitt | Mastery of Sports | 46.700 |
| 60 | Kruz Saechao | Elevate | 46.700 |
| 62 | Wyatt Wickstrom | Mastery of Sports | 46.600 |
| 63 | Theo Choi | SBG Athletics | 46.000 |
| 64 | Max Asyrkin | SBG Athletics | 45.600 |
| 65 | Sammy Aradhya | SBG Athletics | 45.500 |
| 66 | Mason Wang | Metropolitan | 45.200 |
| 67 | Jacob Mitri | Extreme | 44.700 |
| 67 | Russell Henson | Elevate | 44.700 |
| 69 | Hugo Jewell | Extreme | 44.500 |
| 70 | Lev Davydov | SBG Athletics | 43.700 |
| 71 | Nathaniel Mitri | Extreme | 43.300 |
| 72 | Luke Johnson | Extreme | 42.800 |
| 73 | Emmanuel Vestal | Extreme | 42.700 |
| 74 | Joey Jallinger | Metropolitan | 41.500 |
| 75 | Tavasi Ellis | Elevate | 40.300 |
