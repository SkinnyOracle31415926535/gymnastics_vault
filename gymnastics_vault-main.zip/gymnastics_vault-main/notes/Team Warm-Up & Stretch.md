# ✧ 𓊆 Team Warm-Up & Stretch 𓊇 ✧

---

> **[+] In windows**  
> **[~] Restart if done incorrectly**

---

## 𓊈 Warm-Up 𓊉
⋆ · ☆ · ⋆

*Insert new warmup here*
---

## 𓊈 Stretch 𓊉
⋆ · ☆ · ⋆

- **Arm circles**
- **Pike stand**
- **Sitting pike** → 10 reaches + hold
- **Pancake** → 10 reaches + hold
- **Swim through seal**
- **Seal shoulder taps**
- **Everyone pass:** Push-up → Seal → Straddle
- **Spaghetti meatballs cheese**
- **Shoulder stretch** with legs straight, toes pointed
- **Bridge** → Do twice if we have time

---

## 𓊈 If Finish Early… 𓊉
⋆ · ☆ · ⋆

- Sit & socialize calmly
- Arabesque holds
- L-sits
- Handstand practice *(safely)*
- Cartwheel practice *(safely)*
- Visualize routines

---
