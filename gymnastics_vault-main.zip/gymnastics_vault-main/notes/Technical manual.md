# USA Gymnastics – Men’s Development Program  
## Technical Sequence Manual (October 2025)

---

## Power Back Handspring

### Technical Description

The power back handspring begins from an effective “turn-over” round-off, back handspring or tempo salto backward. It begins with the body in a hollow position, hips tucked under, knees bent with the feet well in front of the hips and arms at shoulder level. The first phase (from feet to hands) is lengthened in order to increase linear velocity across the surface of the floor. With the chest in and head neutral, the upper back should “draw or pull” backwards as the arms swing overhead while aggressively extending the legs and pushing backward and off of the floor. The gymnast should demonstrate a tight upper back arch and full shoulder extension until the handstand position is reached slightly past vertical. During the snap down phase, there should be an aggressive push through the wrists while lifting the upper body up and shaping into a hollow position. In order to facilitate a powerful take-off, the second phase (from hands to feet) is dramatically shortened in order to increase rotation, snap down angle, and force into the floor so that the body can leave the floor at vertical with a tight, straight body position to maximize lift and rotation of the body around its center of mass.

### Coaching Points (Emphasize in teaching/learning)

- Aggressive arm swing to a tight arch body position during first phase of back handspring  
- Tight arched handstand should be shown with slight turn over past vertical in handstand (hands in front of the shoulders) to create fast, short and aggressive snap down  
- Use wrists and push through fingers on snap down phase of back handspring  
- Finish snap down and land back handspring in tight hollow body position. Chest in, head neutral, arms in front, feet behind the hips to create vertical take off  

---

## Power Hurdle

### Technical Description

The power-hurdle begins from a standing position with feet together. The gymnast swings the arms forward and upward to a fully extended shoulder angle while the front knee lifts aggressively with the back knee drawing toward the body as well. When the back foot contacts the floor there should be a strong push through the entire back leg as the front knee bends, lunging deeply enough so that hand contact is made while the front foot is still on the floor. The back leg should kick and drive overhead as the front leg forcefully extends while pushing through the hands with a full wrist extension to create linear velocity. This technique is the same for both the front handspring and the round-off.

### Coaching Points (Emphasize in teaching/learning)

- Full arm and shoulder extension on hurdle  
- Aggressive lift of knees to body  
- Square hips and efficient deep lunge position  
- Strong kick of back leg and full wrist extension on push  

---

## Round-Off

### Technical Description

Upon contact with the floor, the first hand should be in line with the front foot. The second hand is placed slightly outside the first hand in the direction of the turn with the fingers turned inward. Shoulders remain open and extended as the turn is initiated. As the first leg drives overhead the second leg should join the first leg after vertical. During the snap down phase, there should be an aggressive push off of the hands, fingers and through the wrists while pulling the arms downward off of the floor to approximately shoulder height. This will shorten the body’s radius of rotation and facilitate the “turn-over” of the round-off. The body should shorten into a hollow position with the legs snapping underneath. The feet should contact the floor well in front of the hips with the hips tucked under, body hollow, head in neutral position. As the feet contact the floor the arms can begin to swing overhead and backward.

### Coaching Points (Emphasize in teaching/learning)

- Strong kick and effective block from hands will provide time to properly turn-over the round-off  
- Strong push through the wrists and fingers as hands leave the floor  
- Arms pulling downward off of the floor  
- Finish snap-down and “turn-over” action with a hollow body shape  
- Head neutral and arms at horizontal with feet well in front of the hips upon landing  

---

## Turnover Swing Backward

### Technical Description

The technical goal of the turnover swing backward is for the gymnast to be able to show a reverse candlestick position at the end of the swing. In order to accomplish this, the major technical point on the turnover swing backward is to allow the body to turn upside down toward vertical as much as the shoulder flexibility of the individual gymnast will allow before applying any deliberate pressure to the rings. Every gymnast will be different in this particular capability and the primary limiting factor is shoulder flexibility. A very flexible gymnast may not need to separate the rings as much. A gymnast with limited shoulder flexibility may push the rings more to the side to facilitate rotation to the vertical position. Most gymnasts with moderate flexibility should finish in an inverted cross position at the peak of the backward swing. The end position is optimal when the shoulders are at or above ring level and between the rings with the feet pointed toward the top of the ring tower.

### Coaching Points (Emphasize in teaching/learning)

- Shoulders below body  
- Hands/Rings out to the side  
- Tight arch in upper shoulders  
- Head neutral in relation to the body, not arms  
- Reverse candlestick position at the end of the swing  

---

## Turnover Swing Forward

### Technical Description

The technical goal of the turnover swing forward is for the athlete to be able to show a candlestick position at the end of the swing. The major technical point on the turnover swing forward is to rotate as close to vertical as possible. Increasing pressure can be applied backward and downward on the rings as long as the rotation is not inhibited. The end position is optimal when the shoulders are at or above ring level with the feet pointed toward the top of the ring tower. The body position should be hollow with the glutes and core muscles tightened and the head forward in a neutral position. The arms may be bent or straight during this swing as long as all requirements for body position are met.

### Coaching Points (Emphasize in teaching/learning)

- Shoulders below body  
- No hip angle  
- Bent arms allowed  
- Candlestick position at end of swing  

---

## Vault

### Hurdle and Board Strike

#### Technical Description

At the final step of the run, the chest will be open and the body will be arched as the final extension of the back leg is completed. As the front knee lifts up to hip height, the arms are swinging back behind the body. The second leg pushes aggressively off the floor and lifts up to join the first knee. The body should be rounded with the hips tucked under during the flight of the hurdle. With the arms back, knees up and body rounded, this creates a “loading” position to forcefully block the board. The feet should be in front of the hips when board contact is made and the shoulders, hips and feet should be aligned with the body at an angle of at least 15°. The arms begin to swing forward as the legs are extending to the board. The core of the body should be extremely tight as contact to the board is made.

### Coaching Points (Emphasize in teaching/learning)

- Front knee to hip height  
- During knee lift, arms swing back and behind the body (arm circle is acceptable)  
- Goal is to “load” the body with knees up and arms back then to forcefully apply as much downward force to the board as possible  
- On board strike, feet should be in front of the hips with shoulders, hips and feet aligned and body at an angle between 0°–15°  

---

## Support Swing Backward

### Technical Description

A well executed support swing backward is performed with the arms turned outward and locked at the elbows. The shoulders should be relaxed enough to allow good freedom and consistency of swing. The body should be kept straight and extended with the head always neutral in relationship to the body. The core and hips should be properly tensioned to maintain a clean body line. Hips should be turned under with good gluteus tension to ensure that there is no arch or pike. As the body swings toward the handstand, the shoulders extend completely to a straight handstand position. Optimally, the support swing backward is completed without interruption in rhythm and in a handstand that could be held if necessary. The swing should have a look of power and aggressiveness as it is performed.

### Coaching Points (Emphasize in teaching/learning)

- Elbows turned outward and locked  
- Shoulders relaxed  
- Body fully extended and properly tensioned  
- Shoulders “locked-out” to handstand at completion of swing  
- Show acceleration, power and rhythm in swing  

---

## Support Swing Forward

### Technical Description

The shoulders should be relaxed enough to allow good freedom and consistency of swing. The body should be kept as straight as possible with the head always neutral in relationship to the body. The core and hips should be properly tensioned to maintain a clean body line. As the forward swing begins the hips should remain open with the shoulders over the hands. The tight, open hip position and slight trailing of the extended legs as the chest passes through vertical support will facilitate a strong kick and forward extension as the body swings toward the end of the front swing. The shoulders extend completely to a rear-support position at the full extent of the gymnast’s shoulder flexibility. Optimally, the support swing forward is completed well above shoulder level with the shoulders over or slightly forward of the hands. The swing should have a look of power and aggressiveness as it is performed.

### Coaching Points (Emphasize in teaching/learning)

- Elbows turned outward and locked  
- Shoulders relaxed  
- Body fully extended and properly tensioned  
- Shoulders reach full rear support extension over hands at completion of swing  
- Body extended above shoulders  
- Show power and acceleration in swing  

---